<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDpFakultebolumTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('dp_fakultebolum', function (Blueprint $table) {
            $table->increments('id');
            $table->string('fakulteadi',200);
            $table->string('bolumadi',200);
            $table->integer('bolumid');
            $table->integer('fakulteid');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
