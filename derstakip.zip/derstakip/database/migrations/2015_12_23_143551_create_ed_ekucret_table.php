<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEdEkucretTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		Schema::create('ed_ekucret', function (Blueprint $table) {
		$table->increments('id');
		$table->integer('akademisyenid');
		$table->integer('ay');
		$table->integer('yil');
		$table->timestamp('tarih');
		$table->double('paramiktari');
		$table->text('neden');
		$table->integer('durum')->default(0);
		$table->integer('eklenecekorgun');
		$table->integer('fakulteid');
		$table->double('gelirvergisi')->default(0);
		$table->double('damgavergisi')->default(0);
		$table->timestamps();
		
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
