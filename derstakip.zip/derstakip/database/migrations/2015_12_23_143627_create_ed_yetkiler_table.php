<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEdYetkilerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		Schema::create('ed_yetkiler', function (Blueprint $table) {
		$table->increments('id');
		$table->integer('personelid');
		$table->integer('yetki');
		$table->integer('fakulteid');
		$table->timestamp('tarih');
		$table->integer('tip');
		$table->timestamp('iptaltarih');
		$table->integer('aktif')->default(1);
		$table->timestamps();
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
