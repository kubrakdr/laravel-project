<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDpDerslerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       
		Schema::create('dp_dersler', function (Blueprint $table) {
            $table->increments('id');
			$table->string('derskodu',20);
            $table->string('dersadi',200);
            $table->integer('bolumid');
            $table->integer('orgun');
			$table->integer('zorunlu');
			$table->integer('tip');
			$table->integer('adet');
			$table->integer('ogrencisayisi');
			$table->integer('sinif');
			$table->integer('donem');
			$table->integer('grupkodu');
			$table->integer('onay');
			
			$table->double('akts');
		    
		    $table->date('gecbastar');
			$table->date('gecbittar');
			$table->integer('yil')->default(2015);
			$table->integer('cp_id');
			$table->integer('bologna')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
