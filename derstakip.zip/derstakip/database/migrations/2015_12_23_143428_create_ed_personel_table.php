<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEdPersonelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		  Schema::create('ed_personel', function (Blueprint $table) {
		   $table->increments('id');
            $table->string('kullaniciadi', 100);
            $table->integer('fakulteid')->default(0);
			$table->integer('bolumid')->default(0);
			$table->string('sicilno', 50)->default('-2');
			$table->string('sifre', 50);
			$table->string('adsoyad');
			$table->string('tcno',15);
			$table->string('emekliliksicilno', 150);
			$table->integer('kadro');
			$table->timestamps();
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
