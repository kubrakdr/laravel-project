<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEdOzelgunlerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		Schema::create('ed_ozelgunler', function (Blueprint $table) {
		$table->increments('id');
		$table->integer('akademisyenid');
		$table->date('tarih');
		$table->integer('fakulteid');
		$table->time('bassaat');
		$table->time('bitsaat');
		$table->text('aciklama');
		$table->timestamps();
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
