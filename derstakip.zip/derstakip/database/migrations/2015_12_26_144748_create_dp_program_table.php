<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDpProgramTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		Schema::create('dp_program', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('dersid');
            $table->integer('akademisyenid');
			$table->integer('derstipi');
			$table->integer('gun');
			$table->integer('orgun');
			$table->integer('bolumid');
			$table->integer('fakulteid');
			$table->integer('yil');
			$table->integer('donem');
			$table->integer('zaman');
			$table->integer('sinif');
			$table->integer('aktif')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
