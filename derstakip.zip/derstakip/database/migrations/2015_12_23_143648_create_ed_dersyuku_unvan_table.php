<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEdDersyukuUnvanTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		Schema::create('ed_dersyuku_unvan', function (Blueprint $table) {
		$table->increments('id');
		$table->integer('akademisyenid');
		$table->integer('unvan');
		$table->integer('dersyuku');
		$table->integer('tip');
		$table->timestamp('bastarih');
		$table->timestamp('bittarih');
		$table->text('aciklama');
		$table->integer('durum')->default(0);
		$table->timestamps();
		
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
