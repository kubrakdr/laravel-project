<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\DpBolumler;
class DpFakulte extends Model
{
    //
    protected $table='dp_fakulteler';

    public function bolum()
    {
    	return DpBolumler::where("fakulteid",$this->id)->get();
    }
}
