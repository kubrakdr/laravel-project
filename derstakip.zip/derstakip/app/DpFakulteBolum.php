<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\DpBolumler;
class DpFakulteBolum extends Model
{
    //
    protected $table='dp_fakultebolum';
    protected $fillable = [
        'fakulteadi', 'bolumadi', 'bolumid', 'fakulteid',
    ];
    public function bolum1(){

    	$this->hasMany('App\DpBolumler','bolumid');
    }

    public function bolum()
    {
    	return DpBolumler::where("fakulteid",$this->id)->get();
    }
}
