<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DpDersler extends Model
{
    //
	 protected $table='dp_dersler';
    protected $fillable = [
        'derskodu', 'dersadi', 'bolumid','orgun','tip','adet','sinif','donem','grupkodu',
		'onay','zorunlu','akts','ogrencisayisi','gecbastar','gecbittar','yil','cp_id','bologna',
    ];
}
