<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DpProgram extends Model
{
    //
    protected $table='dp_program';
    protected $fillable = [
        'dersid', 'akademisyenid', 'derstipi','orgun','gun','bolumid','fakulteid','donem','zaman','yil','sinif','aktif',
    ];
}
