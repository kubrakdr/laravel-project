<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\DpFakulteBolum;


class FakulteController extends Controller
{
    //
	 public function index(){

    		$data=DpFakulteBolum::all();
    		
		return view('fakulteekle')->with("data",$data);
}
public function getir($id){

		$veri=DpFakulteBolum::findorFail($id);
		return view('fakulteduzenle', compact('veri'))->with("data",$veri);	
	}

public function guncelle(Request $request, $id){
		$data=$request->only('fakulteadi', 'fakulteid', 'bolumadi', 'bolumid');
		$gunc=DpFakulteBolum::FindorFail($id); 	
		$gunc->fill($data);
		$gunc->update();

		//return $this->index();

		return redirect()->action('FakulteController@index');
    	
    }
	
public function kaydet(Request $request) {
    	$data=$request->only('fakulteadi', 'fakulteid', 'bolumadi', 'bolumid');

		$veriler= new DpFakulteBolum(); // Deneme::findorFail($id) // select sorgusu ile de alinabilir. nesne olarak gelmeli.
		$veriler->fill($data);
		$veriler->save();
		
		//return $this->index();
		
		return redirect()->action('FakulteController@index');

    
    }
}
