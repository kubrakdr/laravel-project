<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\DpDersler;
use App\DpBolumler;
use App\DpFakulteBolum;
use App\DpFakulte;

class DersController extends Controller
{
    //
	public function index(){
		
		
			
	$data=DpDersler::all();
	
	return view('dersekle')->with("data",$data);
		
	}


	public function getir($id){

		$veri=DpDersler::findorFail($id);
		return view('dersduzenle', compact('veri'))->with("data",$veri);	
	}

	public function guncelle(Request $request, $id){
		$data=$request->only( 'derskodu', 'dersadi', 'bolumid','orgun','tip','adet','sinif','donem','grupkodu',
		'onay','zorunlu','akts','ogrencisayisi','gecbastar','gecbittar','yil','cp_id','bologna');
		$gunc=DpDersler::FindorFail($id); 	
		$gunc->fill($data);
		$gunc->update();

		//return $this->index();

		return redirect()->action('DersController@index');
    }
    
	public function kaydet(Request $request) {
		$data=$request->only( 'derskodu', 'dersadi', 'bolumid','orgun','tip','adet','sinif','donem','grupkodu',
		'onay','zorunlu','akts','ogrencisayisi','gecbastar','gecbittar','yil','cp_id','bologna');
		
		$deneme= new DpDersler(); // Deneme::findorFail($id) // select sorgusu ile de alinabilir. nesne olarak gelmeli.
		$deneme->fill($data);
		$deneme->save();
		
		//return $this->index();
		
		return redirect()->action('DersController@index');
	}
	public function program(){
		//$fakulteid=DpFakulteBolum::all()->distinc();
		//$dersid=DpDersler::all()->distinc();
		$fakulte_bolum=DpFakulte::all();
		
		$dersler=DpDersler::all();

		return view('dersprogrami')->with(array('fakulte_bolum' =>$fakulte_bolum , 'dersler'=>$dersler) );


	}
}
	