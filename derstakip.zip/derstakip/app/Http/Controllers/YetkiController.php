<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\EdPersonel;

class YetkiController extends Controller
{
    //
   // $bilgi=EdPersonel::all();

    public function getir(){

    	
    	return view('anasayfa');
    }
      //
    public function kontrol(Request $request){
    	$data=$request->only('kullaniciadi', 'sifre');
    	
    	$yetki=EdPersonel::find(1);
    	if ($yetki->kullaniciadi == 'admin') {
    		return view('anasayfa');
    	}



    }
}
