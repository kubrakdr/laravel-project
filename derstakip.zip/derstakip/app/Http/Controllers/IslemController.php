<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\EdPersonel;
use App\DpFakulteBolum;
use App\DpDersler;

class IslemController extends Controller
{
    //

    public function index(){

    		$data=EdPersonel::all();
	
		return view('kullaniciekle')->with("data",$data);

    }
    public function hocaindex(){

    		$bolumler=DpFakultebolum::all();
    		$dersler=DpDersler::all();
    		$akademisyenler=EdPersonel::all();
	
		return view('hocaders',['bolumler'=>$bolumler,'dersler'=>$dersler,'akademisyenler'=>$akademisyenler]);

    }
    	public function getir($id){

		$veri=EdPersonel::findorFail($id);
		return view('duzenle', compact('veri'))->with("data",$veri);	
	}
		
	 public function guncelle(Request $request, $id){
		$data=$request->only('kullaniciadi', 'bolumid', 'fakulteid','sicilno','sifre','adsoyad','tcno','emekliliksicilno','kadro');
		$gunc=EdPersonel::FindorFail($id); 	
		$gunc->fill($data);
		$gunc->update();
		
		return redirect()->action('IslemController@index');
    }
    public function kaydet(Request $request) {
    	$data=$request->only('kullaniciadi', 'bolumid', 'fakulteid','sicilno','sifre','adsoyad','tcno','emekliliksicilno','kadro');
		
		$deneme= new EdPersonel(); // Deneme::findorFail($id) // select sorgusu ile de alinabilir. nesne olarak gelmeli.
		$deneme->fill($data);
		$deneme->save();
		
		//return $this->index();
		
		return redirect()->action('IslemController@index');

    
    }
	/*  public function hocakaydet(Request $request) {
    	$data=$request->only('kullaniciadi', 'bolumid', 'fakulteid','sicilno','sifre','adsoyad','tcno','emekliliksicilno','kadro');
		
		$deneme= new EdPersonel(); // Deneme::findorFail($id) // select sorgusu ile de alinabilir. nesne olarak gelmeli.
		$deneme->fill($data);
		$deneme->save();
		
		//return $this->index();
		
		return redirect()->action('IslemController@hocaindex');

    
    }
	*/
}
