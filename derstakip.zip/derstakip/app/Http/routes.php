<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('giris');
});
Route::get('/akademisyenekle', function () {
    return view('akademisyenekle');
});




Route::get('/hocaders', 'IslemController@hocaindex');
Route::get('/cikis', function () {

    return view('cikis');
});

//anasayfa 
Route::group(['prefix' => 'anasayfa'], function () {

    Route::get('','YetkiController@getir');
	Route::post('','YetkiController@kontrol');
});

//kullanici işlemleri
Route::group(['prefix' => 'kullaniciekle'], function () {

    Route::get('','IslemController@index');
	Route::get('duzenle/{id}','IslemController@getir');
	Route::post('duzenle/{id}','IslemController@guncelle');
	Route::post('ekle','IslemController@kaydet');
});

//fakülte 
Route::group(['prefix' => 'fakulteekle'], function () {
    
	Route::get('','FakulteController@index');
	Route::post('ekle','FakulteController@kaydet');
});

//fakulte düzenleme
Route::group(['prefix'=>'fakulteduzenle'], function (){

	Route::get('{id}','FakulteController@getir');
	Route::post('{id}','FakulteController@guncelle');

});
//dersprogramı

Route::get('/dersprogrami','DersController@program');

//ders ekleme-çıkarma
Route::group(['prefix' => 'dersekle'], function () {

	Route::get('','DersController@index');
	Route::post('','DersController@kaydet');
	Route::get('dersduzenle/{id}','DersController@getir');
	Route::post('dersduzenle/{id}','DersController@guncelle');
});



/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
});
