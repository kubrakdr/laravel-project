<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\DpFakulteBolum;

class DpBolumler extends Model
{
    //
    protected $table='dp_bolumler';
    protected $fillable = [
        'bolumadi', 'bolumid', 'fakulteid',
    ];
    public function fakulte(){


    	$this->belongsTo('App\DpFakulteBolum','bolumid');
    }

}
