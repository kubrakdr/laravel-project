<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EdYetkiler extends Model
{
    //
    protected $table='ed_yetkiler';
    protected $fillable = [
        'personelid', 'yetki', 'fakultekodu','tarih','tip','iptaltarih','aktif',
    ];
}
