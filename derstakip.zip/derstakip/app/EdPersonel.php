<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EdPersonel extends Model
{
    //
     protected $table='ed_personel';
    protected $fillable = [
        'kullaniciadi', 'bolumid', 'fakulteid','sicilno','sifre','adsoyad','tcno','emekliliksicilno','kadro',
    ];
}
